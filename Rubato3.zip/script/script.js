$(".main-menu > li").mouseover(function(){
    $(this).children(".sub").stop().slideDown();
//  $(".sub").stop().slideDown();
});
$(".main-menu > li").mouseleave(function(){
$(this).children(".sub").stop().slideUp();
//  $(".sub").stop().slideUp();
});